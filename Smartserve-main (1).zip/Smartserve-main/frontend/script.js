
// =================== CONFIGURATION ===================
const API_BASE = "http://127.0.0.1:5000";

// =================== GLOBAL VARIABLES ===================
let menuData = []; // Will be loaded from API
let cart = [];
let total = 0;
let selectedTable = null;
let currentPaymentMethod = "";
let recommendationCache = {};

// =================== HELPER FUNCTIONS ===================
function formatPrice(price) {
  return `₹${parseFloat(price).toFixed(2)}`;
}
function changeScreen(screenId) {
  document.querySelectorAll(".kiosk-section").forEach((section) => {
    section.classList.remove("active-section");
  });
  document.getElementById(screenId).classList.add("active-section");
}

function manualTableEntry() {
  const tableNum = prompt("Enter your table number:");
  if (tableNum && !isNaN(tableNum)) {
    selectedTable = parseInt(tableNum);
    document.getElementById("tableDisplay").innerText = ` | Table: ${selectedTable}`;
    document.getElementById("confirmTableDisplay").innerText = selectedTable;
    changeScreen("loginBox");
  } else {
    alert("Please enter a valid table number");
  }
}

// =================== API CALLS ===================

// 🔧 FIXED: Fetch tables from correct API endpoint
async function fetchTableStatuses() {
  try {
    const response = await fetch(`${API_BASE}/api/tables`);
    const tables = await response.json();
    updateTableDisplay(tables);
  } catch (error) {
    console.error("❌ Error fetching tables:", error);
    alert("Failed to load tables. Please refresh.");
  }
}

// 🔧 FIXED: Fetch menu from API instead of hardcoded data
async function fetchMenu() {
  try {
    const response = await fetch(`${API_BASE}/api/menu`);
    const data = await response.json();
    
    // Transform API response to match your existing structure
    menuData = data.map(item => ({
      id: item.item_id,
      name: item.name,
      price: parseFloat(item.price),
      img: item.image_url || "placeholder.jpg",
      category: item.category || "General",
      description: item.description || ""
    }));
    
    generateMenuItems(menuData);
    console.log("✅ Menu loaded:", menuData.length, "items");
  } catch (error) {
    console.error("❌ Error loading menu:", error);
    
    generateMenuItems(menuData);
    console.warn("⚠️ Using fallback menu data");
  }
}

// =================== TABLE SELECTION ===================
function selectTable(tableNum) {
  selectedTable = tableNum;
  document.getElementById("tableDisplay").innerText = ` | Table: ${tableNum}`;
  document.getElementById("confirmTableDisplay").innerText = tableNum;
  changeScreen("loginBox");
}

function updateTableDisplay(tables) {
  const tableButtons = document.getElementById('tableButtons');
  let html = '';
  
  tables.forEach(t => {
    const isFree = t.status === 'Free';
    const colorClass = isFree ? 'free-table-btn' : 'occupied-table-btn';
    const disabled = isFree ? '' : 'disabled';
    
    html += `
      <button class="${colorClass}" ${disabled} 
              onclick="${isFree ? `selectTable(${t.table_id})` : ''}">
        Table ${t.table_id} - ${t.status}
      </button>
    `;
  });
  
  html += `<button class="primary-btn" onclick="manualTableEntry()">Enter Table Number</button>`;
  tableButtons.innerHTML = html;
}

// =================== RECOMMENDATION SYSTEM ===================
async function getRecommendationsForDish(food) {
  try {
    updateRecommendationStatus("loading", "Loading...");

    console.log("🔍 Requesting recommendations for:", food); // DEBUG

    const response = await fetch(`${API_BASE}/api/recommend`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ food })
    });

    console.log("📡 Response status:", response.status); // DEBUG

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    console.log("📦 Received data:", data); // DEBUG
    
    const recommendations = data.recommendations || [];
    console.log("🎯 Recommendations array:", recommendations); // DEBUG
    
    // 🔧 FIXED: Transform simple array to objects with similarity
    const recWithSimilarity = recommendations;
    
    console.log("✨ Transformed recommendations:", recWithSimilarity); // DEBUG
    
    displayRecommendations(recWithSimilarity);
    updateRecommendationStatus("success", "Updated");
    
    recommendationCache[food] = recWithSimilarity;

  } catch (error) { 
    console.error("❌ Error fetching recommendations:", error);
    updateRecommendationStatus("error", "Failed");
    displayRecommendations([]);
  }
}

function displayRecommendations(recommendations) {
  const recList = document.getElementById("recommendationsList");
  
  if (!recommendations || recommendations.length === 0) {
    recList.innerHTML = '<p class="recommendation-placeholder">No recommendations available at the moment.</p>';
    return;
  }

  recList.innerHTML = recommendations.map(item => {
    const menuItem = menuData.find(m => m.name === item.name);
    const similarity = (item.similarity * 100).toFixed(0);
    
    if (!menuItem) return ''; // Skip if not in menu
    
    return `
      <div class="recommendation-card" onclick="addToCart('${item.name}', ${menuItem.price})">
        <div class="rec-content">
          <div class="rec-info">
            <span class="rec-name">🍽️ ${item.name}</span>
            <span class="rec-price">${formatPrice(menuItem.price)}</span>
          </div>
          <div class="rec-match">
            <div class="match-bar">
              <div class="match-fill" style="width: ${similarity}%"></div>
            </div>
            <span class="match-text">${similarity}% match</span>
          </div>
        </div>
        <button class="add-rec-btn" onclick="event.stopPropagation(); addToCart('${item.name}', ${menuItem.price})">+</button>
      </div>
    `;
  }).join('');
}

function updateRecommendationStatus(type, text) {
  const statusBadge = document.getElementById("recommendationStatus");
  statusBadge.className = `status-badge status-${type}`;
  statusBadge.textContent = text;
}

function triggerRecommendations() {
  if (cart.length === 0) {
    document.getElementById("recommendationsList").innerHTML = 
      '<p class="recommendation-placeholder">Add items to your cart to see personalized recommendations!</p>';
    updateRecommendationStatus("ready", "Ready");
    return;
  }

  const lastItem = cart[cart.length - 1];
  
  if (recommendationCache[lastItem.name]) {
    displayRecommendations(recommendationCache[lastItem.name]);
    updateRecommendationStatus("success", "Updated");
  } else {
    getRecommendationsForDish(lastItem.name);
  }
}

// =================== MENU GENERATION ===================
function generateMenuItems(items) {
   console.log("Generating items:", items.length);
  const menuContainer = document.getElementById("menuItems");
  menuContainer.innerHTML = "";

  if (items.length === 0) {
    menuContainer.innerHTML = '<p style="text-align: center; color: #999;">No menu items available</p>';
    return;
  }

  items.forEach((item) => {
    const itemHTML = `
      <div class="menu-item" onclick="addToCart('${item.name}', ${item.price})">
        <div class="item-img" style="background-image: url('${item.img}')"></div>
        <div class="item-details">
          <div class="highlight-line"></div>
          <p class="item-name">${item.name}</p>
          <p class="item-category">${item.category}</p>
          <p class="item-price">${formatPrice(item.price)}</p>
        </div>
      </div>
    `;
    menuContainer.innerHTML += itemHTML;
  });
}





// =================== SEARCH FUNCTIONALITY ===================
function searchMenu() {
  const searchTerm = document.getElementById("searchInput").value.toLowerCase();
  const filteredItems = menuData.filter(item => 
    item.name.toLowerCase().includes(searchTerm) || 
    item.category.toLowerCase().includes(searchTerm)
  );
  generateMenuItems(filteredItems);
}

// =================== CART MANAGEMENT ===================
function updateCart() {
  const cartItemsDiv = document.getElementById("cartItems");
  cartItemsDiv.innerHTML = "";
  total = 0;

  if (cart.length === 0) {
    cartItemsDiv.innerHTML = '<p class="empty-cart-message">Your cart is empty</p>';
    document.getElementById("totalPrice").innerHTML = `Total: <span class="total-amount">${formatPrice(0)}</span>`;
    return;
  }

  const itemCounts = cart.reduce((acc, item) => {
    acc[item.id] = acc[item.id] || { ...item, count: 0 };
    acc[item.id].count++;
    total += item.price;
    return acc;
  }, {});

  Object.values(itemCounts).forEach((item) => {
    const itemElement = document.createElement("div");
    itemElement.className = "cart-item";
    itemElement.innerHTML = `
      <div class="cart-item-info">
        <p class="cart-item-name">${item.name}</p>
        <p class="cart-item-details">₹${item.price} × ${item.count}</p>
      </div>
      <div class="cart-item-actions">
        <span class="cart-item-total">₹${(item.price * item.count).toFixed(2)}</span>
        <button class="remove-btn" onclick="removeFromCart(${item.id})">Remove</button>
      </div>
    `;
    cartItemsDiv.appendChild(itemElement);
  });

  document.getElementById("totalPrice").innerHTML = `Total: <span class="total-amount">${formatPrice(total)}</span>`;
}

function addToCart(name, price) {
  const item = menuData.find((i) => i.name === name);
  if (item) {
    cart.push(item);
    updateCart();
    triggerRecommendations();
  }
}

function removeFromCart(itemId) {
  const indexToRemove = cart.findIndex((item) => item.id === itemId);
  if (indexToRemove !== -1) cart.splice(indexToRemove, 1);
  updateCart();
  triggerRecommendations();
}

function clearCart() {
  if (confirm("Are you sure you want to clear your cart?")) {
    cart = [];
    updateCart();
    triggerRecommendations();
  }
}

// =================== PAYMENT FLOW ===================
function checkout() {
  if (!selectedTable) {
    alert("Please select a table first!");
    changeScreen("tableSelectBox");
    return;
  }
  
  if (cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }
  
  document.getElementById("paymentTotalDisplay").innerText = formatPrice(total);
  changeScreen("paymentMethodBox");
}

function selectPaymentMethod(method) {
  currentPaymentMethod = method;
  
  if (method === "Cash") {
    document.getElementById("paymentInputTitle").innerText = "Final Confirmation";
    document.getElementById("processPaymentButtonText").innerText = "Confirm & Pay at Counter";
  } else {
    document.getElementById("paymentInputTitle").innerText = `Step 2: Enter ${method} Details`;
    document.getElementById("processPaymentButtonText").innerText = "Continue to Payment";
  }
  
  changeScreen("paymentInputBox");
}

// 🔧 FIXED: Send order with correct field names matching backend
async function processPayment() {
  const processBtn = document.getElementById("processPaymentButtonText");
  const originalText = processBtn.innerText;
  processBtn.innerText = "Processing...";

  try {
    // Prepare order data matching backend expectations
    const orderData = {
      table_number: selectedTable,
      total_amount: total,
      payment_method: currentPaymentMethod,
      items: cart.map(item => ({
        id: item.id,
        name: item.name,
        price: item.price,
        category: item.category
      }))
    };

    const response = await fetch(`${API_BASE}/api/order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(orderData),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Order failed");
    }

    console.log("✅ Order saved:", data);

    // Show confirmation
    const orderNumber = data.order_id || Math.floor(1000 + Math.random() * 9000);
    document.getElementById("orderNumberDisplay").innerText = `#${orderNumber}`;
    document.getElementById("orderQrCode").src =
      `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=Order-${orderNumber}-Table-${selectedTable}`;

    // Reset cart
    cart = [];
    total = 0;
    recommendationCache = {};
    updateCart();
    
    changeScreen("orderConfirmBox");

  } catch (error) {
    console.error("❌ Error processing order:", error);
    alert("Failed to place order: " + error.message);
    processBtn.innerText = originalText;
  }
}

function resetKiosk() {
  selectedTable = null;
  currentPaymentMethod = "";
  cart = [];
  total = 0;
  recommendationCache = {};
  updateCart();
  document.getElementById("searchInput").value = "";
  document.getElementById("tableDisplay").innerText = "";
  fetchTableStatuses();
  changeScreen("tableSelectBox");
}

// =================== INITIALIZATION ===================
window.addEventListener('DOMContentLoaded', async () => {
  console.log("🚀 Happiness Hut Kiosk Starting...");
  
  // Load tables and menu from API
  await fetchTableStatuses();
  await fetchMenu();
  
  console.log("✅ Kiosk Initialized Successfully");
});