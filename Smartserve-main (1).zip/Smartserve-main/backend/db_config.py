import mysql.connector

def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="12345",  # Change this
        database="happiness_hut"
    )
