import sys
import os
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
from mysql.connector import pooling
from contextlib import contextmanager

app = Flask(__name__)
CORS(app)

# Import ML
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from ml.recommend import recommend_food

# Database connection pool (better than single connection)
db_config = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", "12345"),
    "database": os.getenv("DB_NAME", "happiness_hut"),
    "pool_name": "mypool",
    "pool_size": 5
}

connection_pool = pooling.MySQLConnectionPool(**db_config)

@contextmanager
def get_db_cursor(dictionary=True):
    """Context manager for database operations"""
    connection = connection_pool.get_connection()
    cursor = connection.cursor(dictionary=dictionary)
    try:
        yield cursor
        connection.commit()
    except Exception as e:
        connection.rollback()
        raise e
    finally:
        cursor.close()
        connection.close()

# ===== CUSTOMER APIs =====

@app.route("/api/menu", methods=["GET"])
def get_menu():
    """Get all menu items"""
    try:
        with get_db_cursor() as cursor:
            cursor.execute("SELECT * FROM menu_items WHERE available=1")
            items = cursor.fetchall()
            return jsonify(items), 200
    except Exception as e:
        print("❌ Menu Fetch Error:", e)
        return jsonify({"error": "Failed to fetch menu"}), 500

@app.route("/api/tables", methods=["GET"])
def get_tables():
    """Get all tables with their status"""
    try:
        with get_db_cursor() as cursor:
            cursor.execute("SELECT table_id, status FROM tables")
            tables = cursor.fetchall()
            return jsonify(tables), 200
    except Exception as e:
        print("❌ Tables Fetch Error:", e)
        return jsonify({"error": "Failed to fetch tables"}), 500

@app.route("/api/order", methods=["POST"])
def save_order():
    """Save order and mark table as occupied"""
    try:
        data = request.json
        
        # Validate input
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        table_number = data.get("table_number")
        total_amount = data.get("total_amount")
        payment_method = data.get("payment_method")
        items = data.get("items", [])
        
        if not all([table_number, total_amount, payment_method, items]):
            return jsonify({"error": "Missing required fields"}), 400
        
        with get_db_cursor() as cursor:
            # Insert order
            cursor.execute("""
                INSERT INTO orders (table_number, total_amount, payment_method, items, status)
                VALUES (%s, %s, %s, %s, 'Pending')
            """, (table_number, total_amount, payment_method, json.dumps(items)))
            
            order_id = cursor.lastrowid
            
            # Mark table as occupied
            cursor.execute(
                "UPDATE tables SET status='Occupied' WHERE table_id=%s",
                (table_number,)
            )
            
            return jsonify({
                "message": "Order saved successfully!",
                "order_id": order_id
            }), 200
            
    except Exception as e:
        print("❌ Order Save Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/api/bill", methods=["POST"])
def mark_table_free():
    """Mark table as free after payment"""
    try:
        data = request.json
        table_id = data.get("table_id")
        order_id = data.get("order_id")
        
        if not table_id:
            return jsonify({"error": "table_id is required"}), 400
        
        with get_db_cursor() as cursor:
            # Update table status
            cursor.execute(
                "UPDATE tables SET status='Free' WHERE table_id=%s",
                (table_id,)
            )
            
            # Update order status to completed
            if order_id:
                cursor.execute(
                    "UPDATE orders SET status='Completed' WHERE order_id=%s",
                    (order_id,)
                )
            
            return jsonify({"message": "Table marked as free"}), 200
            
    except Exception as e:
        print("❌ Bill Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/api/recommend", methods=["POST"])
def recommend():
    """Get food recommendations"""
    try:
        data = request.json
        print("📥 Received recommendation request:", data)  # DEBUG
        
        food_name = data.get("food")
        
        if not food_name:
            return jsonify({"error": "Food name is required"}), 400
        
        print(f"🔍 Getting recommendations for: {food_name}")  # DEBUG
        recs = recommend_food(food_name)
        print(f"✅ Recommendations found: {recs}")  # DEBUG
        
        return jsonify({"recommendations": recs}), 200
        
    except Exception as e:
        print("❌ Recommendation Error:", e)
        import traceback
        traceback.print_exc()  # Print full error trace
        return jsonify({"error": "Failed to get recommendations", "details": str(e)}), 500
# ===== STAFF APIs =====

@app.route("/api/staff/orders", methods=["GET"])
def get_orders():
    """Get all orders (for staff)"""
    try:
        with get_db_cursor(dictionary=True) as cursor:
            cursor.execute("""
                SELECT order_id, table_number, total_amount, 
                       payment_method, status, items, order_time
                FROM orders
                ORDER BY order_time DESC
            """)
            orders = cursor.fetchall()
            
            # Convert Decimal to float for JSON serialization
            for order in orders:
                order['total_amount'] = float(order['total_amount'])
                order['order_time'] = str(order['order_time'])
            
            return jsonify(orders), 200
    except Exception as e:
        print("❌ Orders Fetch Error:", e)
        return jsonify({"error": "Failed to fetch orders"}), 500

@app.route("/api/staff/orders/<int:order_id>", methods=["GET"])
def get_order_details(order_id):
    """Get specific order details"""
    try:
        with get_db_cursor() as cursor:
            cursor.execute(
                "SELECT * FROM orders WHERE order_id=%s",
                (order_id,)
            )
            order = cursor.fetchone()
            
            if not order:
                return jsonify({"error": "Order not found"}), 404
            
            return jsonify(order), 200
    except Exception as e:
        print("❌ Order Details Error:", e)
        return jsonify({"error": "Failed to fetch order details"}), 500

@app.route("/api/staff/orders/<int:order_id>", methods=["PUT"])
def update_order_status(order_id):
    """Update order status"""
    try:
        data = request.json
        status = data.get("status")
        
        if not status:
            return jsonify({"error": "Status is required"}), 400
        
        valid_statuses = ["Pending", "Preparing", "Ready", "Served", "Completed", "Cancelled"]
        if status not in valid_statuses:
            return jsonify({"error": f"Invalid status. Must be one of: {valid_statuses}"}), 400
        
        with get_db_cursor() as cursor:
            cursor.execute(
                "UPDATE orders SET status=%s WHERE order_id=%s",
                (status, order_id)
            )
            
            if cursor.rowcount == 0:
                return jsonify({"error": "Order not found"}), 404
            
            return jsonify({"message": "Status updated successfully"}), 200
            
    except Exception as e:
        print("❌ Status Update Error:", e)
        return jsonify({"error": str(e)}), 500
    
@app.route("/api/staff/complete-order/<int:order_id>", methods=["POST"])
def complete_order(order_id):
    """Complete order and free the table"""
    try:
        with get_db_cursor(dictionary=True) as cursor:
            # Get order details first
            cursor.execute(
                "SELECT table_number, status FROM orders WHERE order_id=%s",
                (order_id,)
            )
            order = cursor.fetchone()
            
            if not order:
                return jsonify({"error": "Order not found"}), 404
            
            table_number = order['table_number']
            
            # Update order status to Completed
            cursor.execute(
                "UPDATE orders SET status='Completed' WHERE order_id=%s",
                (order_id,)
            )
            
            # Mark table as Free
            cursor.execute(
                "UPDATE tables SET status='Free' WHERE table_id=%s",
                (table_number,)
            )
            
            return jsonify({
                "message": "Order completed and table freed successfully",
                "table_number": table_number
            }), 200
            
    except Exception as e:
        print("❌ Complete Order Error:", e)
        return jsonify({"error": str(e)}), 500

@app.route("/")
def home():
    return jsonify({
        "message": "Happiness Hut Backend API 🚀",
        "version": "1.0",
        "endpoints": {
            "customer": [
                "GET /api/menu",
                "GET /api/tables",
                "POST /api/order",
                "POST /api/bill",
                "POST /api/recommend"
            ],
            "staff": [
                "GET /api/staff/orders",
                "GET /api/staff/orders/<id>",
                "PUT /api/staff/orders/<id>"
            ]
        }
    })

@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Endpoint not found"}), 404

@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)