import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from ml.recommend import recommend_food

# Test the function
test_food = "Red Rice"  # Use an actual item from your menu
print(f"Testing recommendations for: {test_food}")
result = recommend_food(test_food)
print(f"Result: {result}")
print(f"Type: {type(result)}")