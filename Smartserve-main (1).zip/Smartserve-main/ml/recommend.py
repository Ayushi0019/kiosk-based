# recommend.py
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import os
import pandas as pd

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

df = pd.read_csv(os.path.join(BASE_DIR, "ml", "indian_food.csv"))
df.fillna('', inplace=True)

df['combined_features'] = (
    df['ingredients'] + ' ' +
    df['flavor_profile'] + ' ' +
    df['course'] + ' ' +
    df['state'] + ' ' +
    df['region']
)

tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(df['combined_features'])
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

def recommend_food(food_name, num_recommendations=5):
    if food_name not in df['name'].values:
        return []

    idx = df[df['name'] == food_name].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:num_recommendations + 1]

    recommendations = []
    for index, score in sim_scores:
        recommendations.append({
            "name": df.iloc[index]['name'],
            "similarity": float(score)
        })
    
    return recommendations
